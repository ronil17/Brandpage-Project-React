import styled from "styled-components";
const NumberSelector = ({ setError,error,selectNumber, setselectNumber }) => {
  const arryNumber = [1, 2, 3, 4, 5, 6];


  const numberselectorHandler = (value) =>{
    setselectNumber(value);
    setError("");

  }

  return (
    <NumberSelectorContainer>
      <p style={{color:'red'}}>{error}</p>;
    
      <div className="flex">
        {arryNumber.map((value, i) => (
          <Box
            isselect={value == selectNumber}
            key={i}
            onClick={() => numberselectorHandler(value)}
          >
            {value}
          </Box>
        ))}
      </div>
      <p>Select Number</p>
    </NumberSelectorContainer>  
  );
};

export default NumberSelector;

const NumberSelectorContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: end;

  .flex {
    display: flex;
    gap: 24px;
  }

  p {
    font-size: 24px;
    font-weight: 700px;
  }
`;
const Box = styled.div`
  height: 72px;
  width: 72px;
  cursor: pointer;
  border: 1px solid black;
  display: grid;
  place-items: center;
  font-size: 24px;
  font-weight: 700;
  background-color: ${(props) => (props.isselect ? "black" : "white")};
  color: ${(props) => (props.isselect ? "white" : "black")};
`;
