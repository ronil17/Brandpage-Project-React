import NumberSelector from "./NumberSelector";
import RollDice from "./RollDice";
import Totalscore from "./Totalscore";
import styled from "styled-components";
import { Buttons } from "./styled/Buttons";
import { OutlineButtons } from "./styled/Buttons";
import { useState } from "react";
import Rules from "./Rules";
const GamePlay = () => {
  const [selectNumber, setselectNumber] = useState();
  const [currentDice, setCurrentDice] = useState(1);
  const [showRules, setshowRules] = useState(false);
  const [score, setScore] = useState(0);
  const [error, setError] = useState("");

  const generateRandomNumber = (min, max) => {
    return Math.floor(Math.random() * (max - min) + min);
  };

  const rollDice = () => {
    if (!selectNumber) {
      setError("You have not selected any number");
      return;
    }
    const randomNumber = generateRandomNumber(1, 7);

    setCurrentDice((prev) => randomNumber);

    if (!selectNumber) return;

    if (selectNumber == randomNumber) {
      setScore((prev) => prev + randomNumber);
    } else {
      setScore((prev) => prev - 2);
    }

    setselectNumber(undefined);
  };
  const resetScore = () => {
    setScore(0);
  };
 
  return (
    <MainContainer>
      <div className="top_section">
        <Totalscore score={score} />
        <NumberSelector
          error={error}
          setError={setError}
          selectNumber={selectNumber}
          setselectNumber={setselectNumber}
        />
      </div>
      <RollDice currentDice={currentDice} rollDice={rollDice} />
      <div className="btns">
        <OutlineButtons onClick={resetScore}>Reset</OutlineButtons>
        <Buttons onClick={() => setshowRules((prev) => !prev)}>{showRules ? "Hide" : "Show"} Show Rules</Buttons>
      </div>
      {showRules && <Rules />}
    </MainContainer>
  );
};

export default GamePlay;

const MainContainer = styled.main`
  padding-top: 70px;
  .top_section {
    display: flex;
    justify-content: space-around;
    align-items: end;
  }
  .btns {
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 10px;
    margin-top: 40px;
    flex-direction: column;
  }
`;
