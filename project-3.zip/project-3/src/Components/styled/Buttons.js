import styled from "styled-components";
export const Buttons = styled.button`
  min-width: 220px;
  height: 44px;
  color: white;
  background-color: black;
  padding: 10px 18px;
  border-radius: 5px;
  border: none;
  font-size: 16px;
  border: solid 1px transparent;
  transition: 0.3s background ease-in;
  cursor: pointer;

  &:hover {
    background-color: white;
    color: black;
    border: solid 1px black;
    transition: 0.3s background ease-in;
  }


`;
export const OutlineButtons = styled(Buttons)`

background: white;
border: solid 1px black;
color:black;
 &:hover {
    background-color: black;
    color: white;
    border: solid 1px transparent;
    transition: 0.3s background ease-in;
  }
`;