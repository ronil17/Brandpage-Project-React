import React from "react";
import styled from "styled-components";
import GamePlay from "./Components/GamePlay";
import Startgame from "./Components/Startgame";
import {useState} from "react";
const Button = styled.button`
  background-color: black;
  color: white;
  padding: 10px;
`;


function App() {
  
const [isGameStarted, setIsGameStarted] = useState(false);

const togglePlayGame = () => {
  setIsGameStarted((prev) => !prev);
};


  return (


    <>{isGameStarted ? <GamePlay /> : <Startgame toggle={togglePlayGame} />}</>
  );
}

export default App;
